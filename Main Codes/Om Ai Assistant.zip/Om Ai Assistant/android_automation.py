import requests
import sys

sys.path.append("D:\\programs\\Project Shunn\\Features")

import commands as cd


# # Your MacroDroid Webhook URL
whatsapp_open_url = "https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/whatsapp"
location_share_url = "https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/location"
take_photo_url = "https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/take_photo"
volume_up_url = 'https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/volume_up'
call_my_sister_url = "https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/call_my_sister"

# volume_down_url = "https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/volume_down"

brightness_up_url = "https://trigger.macrodroid.com/04e827a2-11ec-4121-9eae-6f0962dcd483/brightness_up"
# set_alarm_url = "https://trigger.macrodroid.com/f0805605-8974-4897-bf35-694e3c653c56/set_alarm"



# response = requests.get(set_alarm_url)
# # Print response from MacroDroid
# print("Status Code:", response.status_code)
# print("Response:", response.text)

def android_automation(quary):
    if quary in cd.take_picture_commands:
        requests.get(take_photo_url)
    elif quary in cd.call_from_phone_command:
        requests.get(call_my_sister_url)
    elif quary in cd.share_location_commands:
        requests.get(location_share_url)
        print("Location was sent to Gmail")
    elif quary in cd.increase_volume_commands:
        requests.get(volume_up_url)
    elif quary in cd.open_whatsapponphone_command:
        requests.get(whatsapp_open_url)
    elif quary in cd.increase_brightness_commands:
        requests.get(brightness_up_url)

# # Call this function from anywhere
# if __name__ == "__main__":
#      requests.get(brightness_up_url)