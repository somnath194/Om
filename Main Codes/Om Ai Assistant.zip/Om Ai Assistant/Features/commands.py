####################### ALL FILE PATH ###############################
notepad_file_path = "C:\\Windows\\System32\\notepad.exe"
brave_file_path = "C:\\Users\\somi\\AppData\\Local\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
chrome_file_path = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
vscode_file_path = "C:\\Users\\somi\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
arduino_file_path = "C:\\Program Files\\Arduino IDE\\Arduino IDE.exe"
# eagle_file_path = "C:\\EAGLE 9.6.2\\eagle.exe"
paint_file_path = "C:\\Users\\somi\\AppData\\Local\\Microsoft\\WindowsApps\\mspaint.exe"
######################################################################

###################### ALL APPLICATION NAME ##########################
vscode_name = "Visual Studio Code"
google_chrome_name = "Google Chrome"
brave_browser_name = "Brave"
notepad_name = "Notepad"
# eagle_pcb_name = "EAGLE 9.6.2 free"
paint_name = "Paint"
arduino_name = "Arduino IDE 2.3.5"
cmd_name = "Command Prompt"
task_managet_name = "Task Manager"
settings_name = "Settings"
file_name = "Home"
######################################################################


greetings_commands = ["hello om", "hii om",'hii','hello','hi', "hey om", "howdy om", "greetings", "good morning om", "good afternoon om", "good evening om", "hi there om", "hey there om", "what's up om", "hello there om"]
greetings_response = ["Hello! How can I assist you?", "Hi there!", "Hey! What can I do for you?", "Howdy! What brings you here?", "Greetings! How may I help you?", "Good morning! How can I be of service?", "Good afternoon! What do you need assistance with?", 
                      "Good evening! How may I assist you?", "Hey there! How can I help?", "Hi! What's on your mind?", "Hello there! How can I assist you today?"]

goodbye_commands = ["bye",'by', 'byy',"good bye","see you later", "goodbye", "farewell", "take care", "until next time", "bye bye", "catch you later", "have a good one", "by krishna",'exit','ok exit','ok bye','bye krishna']
goodbyy_responses = ["Goodbye!","good bye", "See you later!", "Have a great day!", "Farewell! Take care.", "Goodbye! Until next time.", "Take care! Have a wonderful day.", "Bye bye!", "Catch you later!", "Have a good one!", "So long!"]

thankyou_commands = ["thank you",'thank u', "thanks", "appreciate it", "thank you so much", "thanks a lot", "much appreciated"]
thankyou_response = ["You're welcome!", "Happy to help!", "Glad I could assist.", "Anytime!", "You're welcome! Have a great day.", "No problem!"]

sleep_commands = ['sleep', 'it\'s time to sleep', 'you can rest now', 'bedtime', 'initiate sleep mode', 'sleep well', 'go to sleep', 'go and take rest','rest','take rest', 'time to rest', 'you can sleep now']
sleep_responses = ['Understood go for sleep', 'Sleep mode activated.', 'OK comming back when you call', 'yup boss sleeping', 'Rest well going to sleep mode', 'Sleeping mode initiating.', 'See you next time go to sleep', 'ok, sir go to sleep', 'Acknowledged for sleeping', 'Sleeping']

wake_up_commands = ['wake up','wake up krishna','are you there', 'let\'s get back to work', 'you there', 'time to wake up', 'ready to start the day?', 'let\'s do some work', 'work time', 'awake and alert', 'hello, ready for the day','wake up daddy\'s home']
wake_up_responses = ['Yes, I\'m here.', 'I\'m ready for your commands.', 'How can I assist you today?', 'I\'m awake and at your service.', 'Ready to start the day.', 'Hello! What can I do for you?', 'I\'m here. What do you need?', 'Yes, I\'m listening.', 'What\'s on your agenda?', 'How can I help you today?']

############################################################################## APPLICATIONS ###########################################################################################
open_notepad_commands = ['open notepad', 'launch notepad', 'start notepad','notepad open','run notepad', 'execute notepad', 'begin notepad', 'activate notepad', 'notepad, please open', 'open a new Notepad window', 'run a text editor', 'launch text editor']

open_vscode_commands = ['open vs code', 'launch vs code', 'start vs code','vs code open','run vs code', 'execute vs code', 'begin vs code', 'activate vs code', 
                       'vs code, please open', 'open a new vs code window','open visual studio code', 'launch visual studio code', 'start visual studio code','visual studio code open','run visual studio code', 'execute visual studio code', 'begin visual studio code', 'activate visual studio code',
                         'visual studio code, please open', 'open a new visual studio code window']

open_arduino_commands = ['open arduino', 'open arduino ide','launch arduino','launch arduino ide', 'start arduino','start arduino ide','arduino open','run arduino', 'execute arduino', 'begin arduino','begin arduino ide' ,'activate arduino', 'arduino, please open', 'open a new arduino window','turn on arduino']

open_brave_commands = ['open brave', 'launch brave', 'start brave','brave open','run brave', 'execute brave', 'begin brave', 'activate brave', 'brave, please open', 'open a new brave window','turn on brave',
                      'open brave browser' ,'launch brave browser', 'start brave browser','brave browser open','run brave browser', 'execute brave browser', 'begin brave browser', 'activate brave browser', 'brave browser, please open', 'open a new brave browser window','turn on brave browser']

open_chrome_commands = ['open chrome', 'launch chrome', 'start chrome','chrome open','run chrome', 'execute chrome', 'begin chrome', 'activate chrome', 'chrome, please open', 'open a new chrome window','turn on chrome',
                       'open chrome browser', 'launch chrome browser', 'start chrome browser','chrome browser open','run chrome browser', 'execute chrome browser', 'begin chrome browser', 'activate chrome browser', 'chrome browser, please open', 'open a new chrome browser window','turn on chrome browser']

open_eagle_commands = ['open eagle', 'launch eagle', 'start eagle','eagle open','run eagle', 'execute eagle', 'begin eagle', 'activate eagle', 'eagle, please open', 'open a new eagle window','turn on eagle']

open_paint_commands = ['open paint', 'launch paint', 'start paint','paint open','run paint', 'execute paint', 'begin paint', 'activate paint', 'paint, please open', 'open a new paint window','turn on paint']

close_notepad_commands = ['close notepad', 'exit notepad', 'quit notepad','notepad close','terminate notepad', 'cut notepad', 'end notepad', 'deactivate notepad', 'notepad, please close', 'close  Notepad window', 'terminate a text editor', 'exit text editor']

close_vscode_commands = ['close vs code', 'exit vs code', 'quit vs code','vs code close','terminate vs code', 'cut vs code', 'end vs code', 'deactivate vs code', 
                       'vs code, please close', 'close  vs code window','close visual studio code', 'exit visual studio code', 'quit visual studio code','visual studio code close','terminate visual studio code', 'cut visual studio code', 'end visual studio code', 'deactivate visual studio code',
                         'visual studio code, please close', 'close  visual studio code window']

close_arduino_commands = ['close arduino', 'close arduino ide','exit arduino','exit arduino ide', 'quit arduino','quit arduino ide','arduino close','terminate arduino', 'cut arduino', 'end arduino','end arduino ide' ,'deactivate arduino', 'arduino, please close', 'close  arduino window','turn off arduino']

close_brave_commands = ['close brave', 'exit brave', 'quit brave','brave close','terminate brave', 'cut brave', 'end brave', 'deactivate brave', 'brave, please close', 'close  brave window','turn off brave',
                      'close brave browser' ,'exit brave browser', 'quit brave browser','brave browser close','terminate brave browser', 'cut brave browser', 'end brave browser', 'deactivate brave browser', 'brave browser, please close', 'close  brave browser window','turn off brave browser']

close_chrome_commands = ['close chrome', 'exit chrome', 'quit chrome','chrome close','terminate chrome', 'cut chrome', 'end chrome', 'deactivate chrome', 'chrome, please close', 'close  chrome window','turn off chrome',
                       'close chrome browser', 'exit chrome browser', 'quit chrome browser','chrome browser close','terminate chrome browser', 'cut chrome browser', 'end chrome browser', 'deactivate chrome browser', 'chrome browser, please close', 'close  chrome browser window','turn off chrome browser']

close_eagle_commands = ['close eagle', 'exit eagle', 'quit eagle','eagle close','terminate eagle', 'cut eagle', 'end eagle', 'deactivate eagle', 'eagle, please close', 'close  eagle window','turn off eagle']

close_paint_commands = ['close paint', 'exit paint', 'quit paint','paint close','terminate paint', 'cut paint', 'end paint', 'deactivate paint', 'paint, please close', 'close  paint window','turn off paint']

minimize_brave_commands = ['minimize brave', 'hide brave', 'minimize brave window', 'minimize brave browser','minimise brave', 'hide brave browser' , 'minimise brave window' , 'minimise brave browser']

minimize_chrome_commands = ['minimize chrome', 'hide chrome', 'minimize chrome window', 'minimize chrome browser','minimise chrome', 'hide chrome browser' , 'minimise chrome window' , 'minimise chrome browser']

minimize_notepad_commands = ['minimize notepad', 'hide notepad', 'minimize notepad window', 'minimize text editor','minimise notepad', 'hide text editor' , 'minimise notepad window' , 'minimise text editor']

minimize_eagle_commands = ['minimize eagle pcb', 'hide eagle pcb', 'minimize eagle window', 'minimize eagle','minimise eagle pcb', 'hide eagle' , 'minimise eagle pcb window' , 'minimise eagle']

minimize_paint_commands = ['minimize ms paint', 'hide ms paint', 'minimize paint window', 'minimize paint','minimise ms paint', 'hide paint' , 'minimise ms paint window' , 'minimise paint']

minimize_arduino_commands = ['minimize arduino ide', 'hide arduino ide', 'minimize arduino window', 'minimize arduino','minimise arduino ide', 'hide arduino' , 'minimise arduino ide window' , 'minimise arduino']

minimize_vscode_commands = ['minimize visual studio code', 'hide visual studio code', 'minimize vs code window', 'minimize vs code','minimise visual studio code', 'hide vs code' , 'minimise visual studio code window' , 'minimise vs code']

maximize_brave_commands = ['maximize brave', 'show brave', 'maximize brave window', 'maximize brave browser','maximise brave', 'show brave browser' , 'maximise brave window' , 'maximise brave browser']

maximize_chrome_commands = ['maximize chrome', 'show chrome', 'maximize chrome window', 'maximize chrome browser','maximise chrome', 'show chrome browser' , 'maximise chrome window' , 'maximise chrome browser']

maximize_notepad_commands = ['maximize notepad', 'show notepad', 'maximize notepad window', 'maximize text editor','maximise notepad', 'show text editor' , 'maximise notepad window' , 'maximise text editor']

maximize_eagle_commands = ['maximize eagle pcb', 'show eagle pcb', 'maximize eagle window', 'maximize eagle','maximise eagle pcb', 'show eagle' , 'maximise eagle pcb window' , 'maximise eagle']

maximize_paint_commands = ['maximize ms paint', 'show ms paint', 'maximize paint window', 'maximize paint','maximise ms paint', 'show paint' , 'maximise ms paint window' , 'maximise paint']

maximize_arduino_commands = ['maximize arduino ide', 'show arduino ide', 'maximize arduino window', 'maximize arduino','maximise arduino ide', 'show arduino' , 'maximise arduino ide window' , 'maximise arduino']

maximize_vscode_commands = ['maximize visual studio code', 'show visual studio code', 'maximize vs code window', 'maximize vs code','maximise visual studio code', 'show vs code' , 'maximise visual studio code window' , 'maximise vs code']

###################################################################################################################################################################################

################################################################################ OPEN WEBSITE ##############################################################################################################

open_whatsapp_commands = ['open whatsapp', 'launch whatsapp', 'start whatsapp','whatsapp open','run whatsapp', 'execute whatsapp', 'begin whatsapp', 'activate whatsapp', 'whatsapp, please open', 'open a new whatsapp window','turn on whatsapp']

open_facebook_commands = ['open facebook', 'launch facebook', 'start facebook','facebook open','run facebook', 'execute facebook', 'begin facebook', 'activate facebook', 'facebook, please open', 'open a new facebook window','turn on facebook']

open_insta_commands = ['open insta', 'launch insta', 'start insta','insta open','run insta', 'execute insta', 'begin insta', 'activate insta', 'insta, please open', 'open a new insta window','turn on insta','open instagram','run instagram','lunch instagram']

open_youtube_commands = ['open youtube', 'launch youtube', 'start youtube','youtube open','run youtube', 'execute youtube', 'begin youtube', 'activate youtube', 'youtube, please open', 'open a new youtube window','turn on youtube']

open_gmail_commands = ['open gmail','open mail','run mail','launch gmail', 'start gmail','gmail open','run gmail', 'execute gmail', 'begin gmail', 'activate gmail', 'gmail, please open', 'open a new gmail window','turn on gmail']

open_amazon_commands = ['open amazon', 'launch amazon', 'start amazon','amazon open','run amazon', 'execute amazon', 'begin amazon', 'activate amazon', 'amazon, please open', 'open a new amazon window','turn on amazon']

open_amazon_prime_commands = ['open amazon prime', 'launch amazon prime', 'start amazon prime','amazon prime open','run amazon prime', 'execute amazon prime', 'begin amazon prime', 'activate amazon prime', 'amazon prime, please open', 
                              'open a new amazon prime window','turn on amazon prime','open prime','run prime','launch prime','execute prime']

open_amazon_pay_commands = ['open amazon pay', 'launch amazon pay', 'start amazon pay','amazon pay open','run amazon pay', 'execute amazon pay', 'begin amazon pay', 'activate amazon pay', 'amazon pay, please open', 'open a new amazon pay window','turn on amazon pay']

open_drive_commands = ['open drive','launch drive', 'start drive','drive open','run drive', 'execute drive', 'begin drive', 'activate drive', 'drive, please open', 'open a new drive window','turn on drive',
                            'open google drive','start google drive','activate google drive','run google drive']

open_chatgpt_commands = ['open chat gpt', 'launch chat gpt', 'start chat gpt','chat gpt open','run chat gpt', 'execute chat gpt', 'begin chat gpt', 'activate chat gpt', 'chat gpt, please open', 'open a new chat gpt window','turn on chat gpt',
                         'open chatgpt', 'launch chatgpt', 'start chatgpt','chatgpt open','run chatgpt', 'execute chatgpt', 'begin chatgpt', 'activate chatgpt', 'chatgpt, please open', 'open a new chatgpt window','turn on chatgpt']

open_cricbuzz_commands = ['open cricbuzz', 'launch cricbuzz', 'start cricbuzz','cricbuzz open','run cricbuzz', 'execute cricbuzz', 'begin cricbuzz', 'activate cricbuzz', 'cricbuzz, please open', 'open a new cricbuzz window','turn on cricbuzz',
                         'open cricket score','open cricket','open cricket score']

open_blinkit_commands = ['open blinkit', 'launch blinkit', 'start blinkit','blinkit open','run blinkit', 'execute blinkit', 'begin blinkit', 'activate blinkit', 'blinkit, please open', 'open a new blinkit window','turn on blinkit']



close_tab_commands = ['close tab', 'exit tab', 'quit tab', 'shut tab', 'terminate tab','close browser tab', 'exit browser tab', 'quit browser tab', 'shut browser tab', 'terminate browser tab',
                      'close tab in browser', 'exit tab in browser', 'quit tab in browser', 'shut tab in browser', 'terminate tab in browser','close the tab']


####################################################################### ALL INTERNAL #########################################################################################
open_file_commands = ['open file','open file manager','launch file manager','launch file', 'start file','file open','run file', 'execute file', 'begin file', 'activate file', 'file, please open', 'open a new file window','turn on file']

open_cmd_commands = ['open command prompt', 'launch cmd', 'run command prompt', 'start cmd','open cmd', 'launch cmd', 'start cmd','cmd open','run cmd', 'execute cmd', 'begin cmd', 'activate cmd', 'cmd, please open', 'open a new cmd window','turn on cmd']

open_task_commands = ['open task manager', 'launch task ', 'run task manager', 'start task ','open task', 'launch task manager', 'start task manager','task open','run task manager', 'execute task manager', 'begin task ', 'activate task ', 'task , please open', 'open a new task window','turn on task ']

open_settings_commands = ['open settings', 'access settings', 'launch settings','navigate to settings', 'go to settings', 'view settings','edit settings', 'configure settings', 'modify settings','settings menu','run settings','execute settings']

close_file_commands = ['close file','close file manager','exit file manager','exit file', 'end file','file close','quite file', 'terminate file', 'end file', 'deactivate file', 'file, please close', 'close all file window','turn off file']

close_cmd_commands = ['close command prompt', 'exit cmd', 'quite command prompt', 'end cmd','close cmd', 'exit cmd', 'end cmd','cmd close','quite cmd', 'terminate cmd', 'deactivate cmd', 'cmd, please close', 'close all cmd window ','turn off cmd']

close_task_commands = ['close task manager', 'exit task', 'quite task manager', 'end task','close task', 'exit task manager', 'end task manager','task close','quite task manager', 'terminate task manager', 'deactivate task ', 'task , please close', 'close all task window','turn off task ']

close_settings_commands = ['close settings', 'exit settings','quite settings', 'end settings', 'settings close','deactivate settings', 'close settings menu','turn off settings menu','quite settings','terminate settings']

#######################################################################################################################################################################################

brightness_control_commands = ['set brightness to ','set brightness ' ,'set brightness value to ' ,'adjust screen brightness to ', 'change brightness level to ', 'increase brightness by ', 'decrease brightness by ', 'dim the screen to ',
                                  'dim the screen ','brighten the display by ', 'set screen brightness level to ', 'adjust brightness to ', 'turn up brightness to ', 'turn down brightness to ','put brightness to ','put brightness ','change screen brightness to ',
                                  'adjust screen brightness ','set screen brightness ','turn up brightness by ']

volume_control_commands = ['set volume to ','set volume ' ,'set volume by ','set volume value to ','volume ','adjust pc volume to ','adjast volume by ','volume ','change volume level to ', 'increase volume by ', 'decrease volume by ', 'set pc volume level to ', 'adjust volume  ', 'turn up volume to ', 'turn down volume to ','put volume to ','put volume ','change pc volume to ',
                                  'adjust pc volume ','set pc volume ','turn up volume by ']


########################################################## CHECK PC COMMAND #####################################################################################################################
ip_address_commands = ['what is my ip address', 'get ip address', 'show my ip', 'retrieve ip', 'what is my public ip', 'check ip address','check my ip','tell me my ip adress']

location_commands = ['what is my location', 'get my location', 'where am i', 'find my location', 'locate me','my location','check my location']

temperature_commands = ['what is the current temperature', 'get current temperature', 'temperature right now', 'what is the weather like', 'check the temperature']

internet_speed_commands = ['check internet speed', 'what is my internet speed', 'speed test', 'test my internet speed', 'how fast is my internet','check my internet speed','test internet speed']

##################################################################################################################################################################################################

####################################################### SYSTEM CONFIG COMMANDS ##############################################################################################################
shutdown_commands = ['shutdown', 'turn off computer', 'power down system', 'shut down pc','shut down my computer','turn my pc off']

restart_commands = ['restart', 'restart system', 'computer system', 'system restart', 'restart my pc','restart my computer','restart pc']

pc_sleep_commands = ['sleep my pc', 'put pc to sleep', 'suspend pc','sleep pc', 'sleep system', 'computer system sleep', 'system sleep', 'sleep my pc','sleep my computer','sleep pc']

switch_window_commands = ['switch to next window', 'switch to previous window', 'switch windows', 'alt + tab','switch window']

minimize_all_commands = ['minimize all windows', 'show desktop', 'minimize everything', 'show desktop windows','minimize all','all window down','minimise all windows', 'minimise everything','minimise all']

minimize_current_windows_commands = ['minimize current window','minimise current tab', 'hide current window', 'minimize this', 'minimize it','down this','down it','minimize','minimise current window', 'minimise this', 'minimise it','minimise']

pause_commands = ['pause','play the song','play','play music','pause the song', 'stop music', 'pause playback','pause the video','stop the video']

hit_space_commands = ['hit space','press space','enter space','now hit space','now press space','type space','hit the space button']

full_screen_commands = ['full screen','do full screen','press f', 'enter full screen', 'toggle full screen', 'maximize window','maximise window','now full screen','enter f','undo full screen','short screen']

hit_enter_commands = ['hit enter', 'press enter', 'enter', 'submit', 'confirm','ok enter','now enter','ok submit','now submit']

#################################################################################################################################################################################################

######################################################## WEB SEARCH COMMANDS #######################################################################################################
youtube_search_commands = ['search on youtube','search on yt','search youtube','search from youtube','youtube search','yt search']

google_search_commands = ['search google', 'google search', 'look up on google', 'find information', 'google for me','search on google','find from google','search from google']

typing_commands = ['type', 'enter text', 'input', 'write', 'send keys','insert text', 'keyboard input', 'fill in','input text','now type','now write','now insert text']

#####################################################################################################################################################################################

######################################### HOME AUTOMATION #######################################################################################################################
light_on_commands = ['room light on', 'turn on lights', 'switch on lights','my room light on','tubelight on','on light','light on','on the light','turn on light','turn on the light']
light_off_commands = ['room light off', 'light off', 'turn off light', 'switch off light','my room light off','tubelight off','off light','off the light','turn off the light']

bulb_on_commands = ['bulb on','turn on bulb','switch on bulb','my bulb on','on bulb','turn bulb on','switch bulb on','on the bulb','turn on the bulb']
bulb_off_commands = ['bulb off','bulb of','turn off bulb','switch off bulb','my bulb off','off bulb', 'turn bulb off', 'switch bulb off', 'off the bulb','turn off the bulb']

fan_on_commands = ['room fan on', 'fan on', 'turn on fan', 'switch on fan','my room fan on','switch on the fan','on fan','on the fan','fan speed 4','fan speed full','fan speed at highest','highest fan speed','put fan on full','turn on the fan']
fan_off_commands = ['room fan off', 'fan off', 'turn off fan', 'switch off fan','my room fan off','tubefanoff','off fan','off the fan','turn off the fan','turn off the fan']

fan_speed2_commands = ['fan speed half','fan speed 2','fan speed 50%','put fan on second speed','put fan speed 50%','fan speed label half','decrease fan speed by 50%','decrease fan speed by half']
fan_speed3_commands = ['fan speed 3','fan speed 75%','put fan on third speed','put fan speed 75%','fan speed label 3','decrease fan speed by 75%','decrease fan speed by third']

wled_on_commands = ['just on the LED','just turn on the strip light','turn on the led strip light','turn on the w led','led street light on','activate led','please turn on led','switch on the led strip light','activate the led strip light',
                    'activate led strip light','activate w led','please turn on w led','w led on','turn on w led','turn on led']
wled_off_commands = ['turn off the led strip light','turn off the blue led','led street light off','deactivate led','please turn off led','switch off the led strip light','deactivate the led strip light',
                     'deactivate led strip light','deactivate w led','please turn off w led','w led off','turn off w led','turn off led']
wled_music_sync_commands = ["activate music singh mode","activate music sink mode","activate music sync mode","turn on music sink mode","activate music sync mode",'activate music mode','activate party mode'
                                       "turn on the music sync mode","music sink mode activate","please turn on the music sink mode","activate music singing mode","activate party mode","please turn on the party mode"
]
wled_colour_commands = ['set w led colour to ',"set w led colour ","set w led colour by ","set w led colour value to ","w led colour ","adjust wled colour to ","adjust wled colour by ","wled colour ",
                        "change w led colour to ","increase w led colour by ","decrease w led colour by ","set w led colour level to ","adjust w led colour ","turn wled colour to ","turn down wled colour to ",
                        "put led colour to ","led colour ","set led color ","set led color to ","change w led colour to ","adjust w led colour ","set w led colour ","turn up wled colour by "]
set_shelf_color = ['set shelf colour to ',"set shelf colour ","set shelf colour by ","set self colour to ",'self colour to ','set self colour to ']

bathroom_light_on_commands = ['bathroom light on', 'turn on bathroom light', 'switch on bathroom light', 'my bathroom light on', 'bathroom tubelight on', 'on bathroom light', 'light on in the bathroom', 
                              'on the light in the bathroom', 'turn on bathroom light', 'turn on the light in the bathroom', 'activate bathroom light', 'illuminate bathroom', 'let there be light in the bathroom']

bathroom_light_off_commands = ['bathroom light off', 'turn off bathroom light', 'switch off bathroom light', 'my bathroom light off', 'bathroom tubelight off', 'off bathroom light', 'light off in the bathroom', 
                               'off the light in the bathroom', 'turn off the light in the bathroom', 'deactivate bathroom light', 'extinguish bathroom light', 'turn the bathroom light off']
outside_light_on_commands = ['outside light on', 'turn on outside light', 'switch on outside light', 'my outside light on', 'front light on', 'backyard light on', 'garden light on', 'patio light on', 
                             'on outside light', 'light on outside', 'on the outside light', 'turn on the outside light', 'activate outside light', 'illuminate outside']
outside_light_off_commands = ['outside light off', 'turn off outside light', 'switch off outside light', 'my outside light off', 'front light off', 'backyard light off'
                              , 'off outside light', 'light off outside', 'off the outside light', 'turn off the outside light', 'deactivate outside light']
stair_light_on_commands = ['stair light on', 'turn on stair light', 'switch on stair light', 'my stair light on', 'hallway light on', 'landing light on', 'on stair light', 'light on the stairs', 
                           'on the light on the stairs', 'turn on the light on the stairs', 'activate stair light', 'illuminate the stairs']
stair_light_off_commands = ['stair light off', 'turn off stair light', 'switch off stair light', 'my stair light off', 'hallway light off', 'landing light off', 'off stair light', 'light off the stairs',
                             'off the light on the stairs', 'turn off the light on the stairs', 'deactivate stair light', 'extinguish the stair light']
outside_camera_on_commands = ['outside camera on', 'turn on outside camera', 'switch on outside camera', 'my outside camera on', 'front camera on', 'backyard camera on', 
                              'on outside camera', 'camera on outside', 'on the outside camera', 'turn on the outside camera', 'activate outside camera', 'start outside camera']
outside_camera_off_commands = ['outside camera off', 'turn off outside camera', 'switch off outside camera', 'my outside camera off', 'front camera off', 'backyard camera off',
                               'off outside camera', 'camera off outside', 'off the outside camera', 'turn off the outside camera', 'deactivate outside camera', 'stop outside camera']
pc_on_commands = ["turn on pc", "switch on pc", "power on pc", "boot up pc", "start pc",
                  "turn on computer", "switch on computer", "power on computer", "boot up computer", "start computer",
                  "wake up pc", "wake the pc", "turn the pc on", "power the pc on"]

pc_off_commands = ["turn off pc", "switch off pc", "power off pc", "shut down pc", "turn off computer",
                   "switch off computer", "power off computer", "shut down computer", "sleep pc", "put pc to sleep",
                   "hibernate pc", "put pc in hibernate", "turn the pc off", "power the pc off"]

###################################################################################################################################################################################

#######################################################Computer Vision Commands####################################################################################################
facerecognition_activate_command = ['activate face recognition', 'detect face', 'face detection mode on']
facerecognition_deactivate_command = ['deactivate face recognition', 'exit from face detection', 'face detection mode off',"face detection mode of"]

cctv_on_commands = ["turn on cctv camera","activate cctv camera","activate cctv mode","cctv camera on","please turn on the cctv camera","activate the cctv camera","activate cctv"]
cctv_off_commands = ["turn off cctv camera","deactivate cctv camera","deactivate cctv mode","cctv camera off","please turn off the cctv camera","deactivate the cctv camera","deactivate cctv"]
activate_hand_mouse_commands = ["activate hand mouse mode","start hand mouse mode","activate hand mouse recognition","enable hand mouse mode","turn on hand mouse mode","hand mouse mode on",
                                "begin hand mouse mode","initiate hand mouse mode","start hand tracking for mouse","activate hand tracking mouse","launch hand mouse mode","engage hand mouse mode",
                                "switch to hand mouse mode"]
deactivate_hand_mouse_commands = ["deactivate hand mouse mode","stop hand mouse mode","disable hand mouse mode","turn off hand mouse mode","hand mouse mode off","end hand mouse mode",
                                  "terminate hand mouse mode","stop hand tracking for mouse","deactivate hand tracking mouse","exit hand mouse mode","disengage hand mouse mode",
                                  "switch off hand mouse mode","revert to normal mouse mode"]

################################################ ANDROID AUTOMATION ################################################################################################################

open_camera_command = ['open camera','open my phone camera','launch the camera','turn on the phone camera','show my phone camera']
open_whatsapponphone_command = ['open whatsapp on phone','show whatsapp on phone','turn on whatsapp','show whatsapp on my phone']
call_from_phone_command = ['call my sister','please call sister','call sister','do a phone call to sister','please call sister','connect with sister']
take_picture_commands = ["take a picture", "please click a selfie", "please take a picture", "click photo", "take a selfie", "please take a selfie", "from click photo",
                                     "take a picture on my phone", "take a selfie on my phone"]
increase_volume_commands = ["please increase the volume of my phone","increase the volume of my phone","volume increase on my phone","volume up on my phone"]
decrease_volume_commands = ["please decrease the volume","decrease the volume","volume decrease","volume down"]

increase_brightness_commands = ["please increase the brightness","increase the brightness","brightness increase","brightness up"]
decrease_brightness_commands = ["please decrease the brightness","decrease the brightness","brightness decrease","brightness down"]
share_location_commands = ["please share my location","share my location","location share"]
set_alarm_commands = ["set alarm at today 9:00 p.m.", "set the alarm for 9:00 p.m.", "please set alarm in my phone for 9:00 p.m.",
                      "please set alarm on my phone at 9:00 p.m.","set alarm at 9:00 p.m."]

cut_the_call_command = ['cut the call','cut this call','terminate call','cut this call']
close_camera_command = ['close camera','close my phone camera','off the camera','turn off the phone camera','hide my phone camera']
close_whatsapponphone_command = ['close whatsapp on phone','hide whatsapp on phone','turn off whatsapp']

####################################################################################################################################################################################

open_applicatioin_commands = open_brave_commands + open_chrome_commands + open_notepad_commands + open_arduino_commands + open_eagle_commands + open_vscode_commands + open_paint_commands

close_applicatioin_commands = (close_brave_commands + close_chrome_commands + close_notepad_commands + close_arduino_commands + close_eagle_commands + close_vscode_commands + close_paint_commands + 
                               close_cmd_commands + close_settings_commands + close_task_commands + close_file_commands + close_tab_commands)

minimize_applicatioin_commands = minimize_brave_commands + minimize_chrome_commands + minimize_notepad_commands + minimize_arduino_commands + minimize_eagle_commands + minimize_vscode_commands + minimize_paint_commands

maximize_applicatioin_commands = maximize_brave_commands + maximize_chrome_commands + maximize_notepad_commands + maximize_arduino_commands + maximize_eagle_commands + maximize_vscode_commands + maximize_paint_commands

open_website_commands = (open_whatsapp_commands + open_facebook_commands + open_insta_commands + open_cricbuzz_commands + open_chatgpt_commands + open_youtube_commands + open_gmail_commands + open_amazon_commands +
                         open_amazon_pay_commands + open_amazon_prime_commands + open_blinkit_commands + open_drive_commands)

open_internal_application_commands = open_file_commands + open_cmd_commands + open_task_commands + open_settings_commands

system_configure_commands = (minimize_all_commands + minimize_current_windows_commands + switch_window_commands + pc_sleep_commands + shutdown_commands + restart_commands + pause_commands + hit_enter_commands + full_screen_commands +
                             hit_space_commands)

check_pc_commands = location_commands + internet_speed_commands + ip_address_commands + temperature_commands

home_automation_commands = (light_off_commands + light_on_commands + fan_on_commands + fan_off_commands + fan_speed2_commands + fan_speed3_commands + bulb_on_commands + bulb_off_commands
                             + bathroom_light_on_commands  + bathroom_light_off_commands + outside_light_on_commands + outside_light_off_commands + outside_camera_on_commands + outside_camera_off_commands
                            + stair_light_on_commands + stair_light_off_commands )
wled_automation_commands = wled_colour_commands + wled_music_sync_commands + wled_on_commands + wled_off_commands + set_shelf_color

computer_vision_commands = facerecognition_activate_command + cctv_on_commands + activate_hand_mouse_commands + facerecognition_deactivate_command + cctv_off_commands + deactivate_hand_mouse_commands

android_automation_commands = open_whatsapponphone_command + share_location_commands + call_from_phone_command + take_picture_commands + increase_volume_commands