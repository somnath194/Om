from multiprocessing import Process
import sys

import om  # your assistant task execution (rename 2nd script to smart_assistant.py)
import webSpeech_backend    # your Flask speech server (rename 1st script to speech_server.py)

if __name__ == "__main__":
    # Start Flask app as one process
    
    # Start Smart Assistant as another process
    p1 = Process(target=om.taskexection)
    p2 = Process(target=webSpeech_backend.run_flask)

    
    p1.start()
    p2.start()

    p1.join()
    p2.join()



